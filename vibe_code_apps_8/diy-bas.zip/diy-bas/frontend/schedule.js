(function () {
  'use strict';

  const DAYS = [
    'Sunday',
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
  ];

  const HOUR_ROW_PX = 40;
  const HEADER_ROW_PX = HOUR_ROW_PX;
  const HOURS = 24;
  const GRID_ROWS = 1 + HOURS;

  const INITIAL_BACNET_POINTS = [
    { id: 'ahu', name: 'AHU supply air temp', objectId: 'AV:1' },
    { id: 'vav', name: 'VAV zone flow', objectId: 'AV:2' },
    { id: 'clg', name: 'Cooling setpoint', objectId: 'AV:3' },
    { id: 'htg', name: 'Heating setpoint', objectId: 'AV:4' },
    { id: 'fan', name: 'Supply fan command', objectId: 'BV:1' },
    { id: 'econ', name: 'Economizer enable', objectId: 'BV:2' },
  ];

  function timeToMinutes(time) {
    const [h, m] = time.split(':').map(Number);
    return h * 60 + m;
  }

  function cloneWeekForm(form) {
    const next = {};
    for (const d of DAYS) {
      next[d] = { ...form[d] };
    }
    return next;
  }

  function cloneBacnetPoints(points) {
    return points.map((p) => ({ ...p }));
  }

  function blocksFromOperatingWeek(form, profileName) {
    const out = [];
    for (const day of DAYS) {
      const row = form[day];
      if (row.noSchedule) continue;
      const startM = timeToMinutes(row.start);
      const endM = timeToMinutes(row.end);
      if (endM <= startM) continue;
      out.push({
        id: `${day}-run`,
        day,
        start: row.start,
        end: row.end,
        label: profileName,
      });
    }
    return out;
  }

  function defaultWeekForm() {
    const run = () => ({
      noSchedule: false,
      start: '08:00',
      end: '17:00',
    });
    const off = () => ({
      noSchedule: true,
      start: '08:00',
      end: '17:00',
    });
    return {
      Sunday: off(),
      Monday: run(),
      Tuesday: run(),
      Wednesday: run(),
      Thursday: run(),
      Friday: run(),
      Saturday: off(),
    };
  }

  function mergeWeekForm(saved) {
    const d = defaultWeekForm();
    if (!saved || typeof saved !== 'object') return d;
    for (const day of DAYS) {
      if (saved[day]) d[day] = { ...d[day], ...saved[day] };
    }
    return d;
  }

  function uuid() {
    try {
      const c = globalThis.crypto;
      if (c && typeof c.randomUUID === 'function') {
        return c.randomUUID();
      }
    } catch {
      /* randomUUID is restricted to secure contexts in some browsers */
    }
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (ch) => {
      const r = (Math.random() * 16) | 0;
      const v = ch === 'x' ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  }

  function initialSchedules() {
    const id = uuid();
    return {
      list: [
        {
          id,
          name: 'Default',
          form: defaultWeekForm(),
          bacnetPoints: cloneBacnetPoints(INITIAL_BACNET_POINTS),
        },
      ],
      activeId: id,
    };
  }

  function parseISODate(iso) {
    const [y, mo, d] = iso.split('-').map(Number);
    return new Date(y, mo - 1, d);
  }

  function formatISO(d) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  function formatPrettyLong(iso) {
    const [y, mo, d] = iso.split('-').map(Number);
    const dt = new Date(y, mo - 1, d);
    return dt.toLocaleDateString(undefined, {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  }

  function eachDayIsoBetween(isoA, isoB) {
    let a = parseISODate(isoA);
    let b = parseISODate(isoB);
    if (b < a) {
      const t = a;
      a = b;
      b = t;
    }
    const out = [];
    for (
      let cur = new Date(a.getFullYear(), a.getMonth(), a.getDate());
      cur <= new Date(b.getFullYear(), b.getMonth(), b.getDate());
      cur.setDate(cur.getDate() + 1)
    ) {
      out.push(formatISO(cur));
    }
    return out;
  }

  function mergeNewHolidayDates(existing, isoStrings) {
    const next = existing.slice();
    const seen = new Set(next.map((h) => h.date));
    for (const dateStr of isoStrings) {
      if (seen.has(dateStr)) continue;
      seen.add(dateStr);
      next.push({
        id: uuid(),
        date: dateStr,
        unoccupied: false,
      });
    }
    next.sort((a, b) => a.date.localeCompare(b.date));
    return next;
  }

  function getBlockStyle(block) {
    const dayIndex = DAYS.indexOf(block.day);
    const topMinutes = timeToMinutes(block.start);
    const endMinutes = timeToMinutes(block.end);
    const bodyTopPx = (topMinutes / (HOURS * 60)) * HOURS * HOUR_ROW_PX;
    const heightPx = ((endMinutes - topMinutes) / 60) * HOUR_ROW_PX;
    return {
      left: `calc(80px + (100% - 80px) * ${dayIndex} / 7)`,
      width: `calc((100% - 80px) / 7 - 2px)`,
      top: `${HEADER_ROW_PX + bodyTopPx}px`,
      height: `${heightPx}px`,
    };
  }

  const seed = initialSchedules();
  const now = new Date();
  const state = {
    schedules: seed.list,
    activeScheduleId: seed.activeId,
    holidays: [],
    holidayPickerMode: 'multiple',
    holidayViewYear: now.getFullYear(),
    holidayViewMonth0: now.getMonth(),
    holidayMultiSelected: new Set(),
    holidayRangeFrom: null,
    holidayRangeTo: null,
  };

  /** @type {HTMLElement | null} */
  let elScheduleGrid = null;
  /** @type {HTMLElement | null} */
  let elEventLayer = null;
  /** @type {HTMLSelectElement | null} */
  let elProfileSelect = null;
  /** @type {HTMLButtonElement | null} */
  let elDeleteProfile = null;
  /** @type {HTMLElement | null} */
  let elCalendarHint = null;
  /** @type {HTMLElement | null} */
  let elScheduleGridOuter = null;
  /** @type {HTMLElement | null} */
  let elHolidayPickerHost = null;
  /** @type {HTMLButtonElement | null} */
  let elBtnHolidayAdd = null;
  /** @type {HTMLParagraphElement | null} */
  let elHolidayRangeHint = null;
  /** @type {HTMLElement | null} */
  let elHolidayListHost = null;
  /** @type {HTMLElement | null} */
  let elBacnetTbody = null;
  /** @type {HTMLButtonElement | null} */
  let elBtnModeMulti = null;
  /** @type {HTMLButtonElement | null} */
  let elBtnModeRange = null;
  /** @type {HTMLElement | null} */
  let mountRoot = null;

  function getActiveProfile() {
    return (
      state.schedules.find((s) => s.id === state.activeScheduleId) ||
      state.schedules[0]
    );
  }

  function holidayDateSet() {
    return new Set(state.holidays.map((h) => h.date));
  }

  function buildLayout() {
    const root = mountRoot;
    if (!root) return;
    root.innerHTML = `
      <header class="page-header">
        <div class="schedule-page-head">
          <div>
            <h1>diy-bas schedule</h1>
            <p class="lede">
              Select a schedule to drive the week view and operating times. BACnet points at the bottom belong only to the active schedule.
            </p>
          </div>
          <div class="schedule-save-row">
            <span id="schedule-save-status" class="schedule-save-status" aria-live="polite"></span>
            <button type="button" class="btn primary" id="btn-schedule-save">Save &amp; push to BACnet</button>
          </div>
        </div>
      </header>

      <section class="panel profile-panel" aria-labelledby="profile-heading">
        <h2 id="profile-heading">Schedule</h2>
        <p class="section-hint">
          Choose which schedule is active. The calendar and operating week always
          reflect that selection.
        </p>
        <div class="profile-toolbar">
          <label class="profile-select-label" for="profile-select">Select schedule</label>
          <select id="profile-select" class="control profile-select" aria-label="Active schedule"></select>
          <div class="profile-add">
            <input id="new-profile-name" class="control" placeholder="New schedule name" aria-label="Name for new schedule" />
            <button type="button" class="btn primary" id="btn-add-profile">Add schedule</button>
          </div>
          <button type="button" class="btn danger" id="btn-delete-profile">Delete active schedule</button>
        </div>
      </section>

      <section class="panel calendar-panel" aria-labelledby="cal-heading">
        <div class="calendar-head">
          <h2 id="cal-heading">Weekly calendar</h2>
          <span class="badge-readonly" title="Driven by the selected schedule">Read-only</span>
        </div>
        <p class="calendar-hint" id="calendar-hint"></p>
        <div id="weekly-calendar-mount"></div>
      </section>

      <section class="panel form-panel" aria-labelledby="form-heading">
        <h2 id="form-heading">Operating week</h2>
        <p class="section-hint" id="operating-hint"></p>
        <div class="form-table" id="operating-table" role="table">
          <div class="form-row form-row-head" role="row">
            <span role="columnheader">Day</span>
            <span role="columnheader" title="No schedule / unoccupied this weekday">Off</span>
            <span role="columnheader">Start</span>
            <span role="columnheader">Stop</span>
          </div>
        </div>
      </section>

      <section class="panel holiday-panel" aria-labelledby="holiday-heading">
        <h2 id="holiday-heading">Holiday calendar</h2>
        <p class="section-hint">
          <strong>Individual dates:</strong> tap days (multi-select), then add.
          <strong>Date range:</strong> click the start day, then the end day (like
          sliding a span), then add — every day in between is included. New entries
          default <strong>unoccupied</strong> unchecked; use Delete to remove.
        </p>
        <div class="holiday-mode-toggle" role="group" aria-label="Holiday selection mode">
          <button type="button" class="btn mode-btn" id="btn-holiday-mode-multi" data-action="holiday-mode" data-mode="multiple">Individual dates</button>
          <button type="button" class="btn mode-btn" id="btn-holiday-mode-range" data-action="holiday-mode" data-mode="range">Date range</button>
        </div>
        <div class="holiday-layout">
          <div class="holiday-picker-wrap">
            <div id="holiday-picker-host"></div>
            <button type="button" class="btn primary holiday-add-btn" id="btn-holiday-add">Add selected dates as holidays</button>
            <p class="holiday-range-hint" id="holiday-range-hint" hidden></p>
            <p class="holiday-legend">
              <span class="legend-swatch already" aria-hidden="true"></span> Already a holiday
            </p>
          </div>
          <div class="holiday-list-wrap">
            <h3 class="holiday-list-title">Holiday list</h3>
            <div id="holiday-list-host"></div>
          </div>
        </div>
      </section>

      <section class="panel" aria-labelledby="bacnet-heading">
        <h2 id="bacnet-heading">BACnet points</h2>
        <p class="section-hint" id="bacnet-hint"></p>
        <div class="bacnet-table">
          <div class="bacnet-row bacnet-row-head">
            <span>Display name</span>
            <span>BACnet object ID (optional)</span>
            <span class="bacnet-actions-col"></span>
          </div>
          <div id="bacnet-rows"></div>
          <div class="bacnet-row bacnet-add">
            <input class="control" id="bacnet-new-name" placeholder="New point name" aria-label="New BACnet point name" />
            <input class="control" id="bacnet-new-oid" placeholder="Object ID (optional)" aria-label="New BACnet object ID" />
            <div class="bacnet-actions">
              <button type="button" class="btn primary" id="btn-bacnet-add">Add point</button>
            </div>
          </div>
        </div>
      </section>
    `;

    elProfileSelect = root.querySelector('#profile-select');
    elDeleteProfile = root.querySelector('#btn-delete-profile');
    elCalendarHint = root.querySelector('#calendar-hint');
    elHolidayPickerHost = root.querySelector('#holiday-picker-host');
    elBtnHolidayAdd = root.querySelector('#btn-holiday-add');
    elHolidayRangeHint = root.querySelector('#holiday-range-hint');
    elHolidayListHost = root.querySelector('#holiday-list-host');
    elBacnetTbody = root.querySelector('#bacnet-rows');
    elBtnModeMulti = root.querySelector('#btn-holiday-mode-multi');
    elBtnModeRange = root.querySelector('#btn-holiday-mode-range');

    const mount = root.querySelector('#weekly-calendar-mount');
    if (mount) {
      elScheduleGridOuter = mount;
      const grid = buildScheduleGridElement();
      mount.appendChild(grid);
      elScheduleGrid = grid;
      elEventLayer = grid.querySelector('.event-blocks-layer');
    }

    const opTable = root.querySelector('#operating-table');
    if (opTable) {
      for (const day of DAYS) {
        const row = document.createElement('div');
        row.className = 'form-row';
        row.setAttribute('role', 'row');
        row.dataset.day = day;
        row.innerHTML = `
          <span class="day-cell" role="rowheader">${day}</span>
          <label class="form-off-cell" title="No run this day (unoccupied)">
            <input type="checkbox" class="op-no-schedule" data-day="${day}" />
            <span class="form-off-label">No schedule</span>
          </label>
          <label class="sr-only" for="start-${day}">Start time ${day}</label>
          <input id="start-${day}" class="control time op-start" type="time" data-day="${day}" />
          <label class="sr-only" for="end-${day}">Stop time ${day}</label>
          <input id="end-${day}" class="control time op-end" type="time" data-day="${day}" />
        `;
        opTable.appendChild(row);
      }
    }

    root.querySelector('#btn-add-profile')?.addEventListener('click', onAddProfile);
    root.querySelector('#btn-delete-profile')?.addEventListener('click', onDeleteProfile);
    elProfileSelect?.addEventListener('change', onProfileSelectChange);
    root.querySelector('#new-profile-name')?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') onAddProfile();
    });

    root.querySelector('#operating-table')?.addEventListener('change', onOperatingChange);

    elBtnModeMulti?.addEventListener('click', () => setHolidayMode('multiple'));
    elBtnModeRange?.addEventListener('click', () => setHolidayMode('range'));
    elBtnHolidayAdd?.addEventListener('click', onHolidayAddClick);

    elHolidayListHost?.addEventListener('change', onHolidayListChange);
    elHolidayListHost?.addEventListener('click', onHolidayListClick);

    root.querySelector('#btn-bacnet-add')?.addEventListener('click', onBacnetAdd);
    root.querySelector('#bacnet-new-name')?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') onBacnetAdd();
    });
    root.querySelector('#bacnet-new-oid')?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') onBacnetAdd();
    });
    elBacnetTbody?.addEventListener('input', onBacnetInput);
    elBacnetTbody?.addEventListener('click', onBacnetClick);

    wireScheduleServerUi(root);
  }

  function wireScheduleServerUi(root) {
    root.querySelector('#btn-schedule-save')?.addEventListener('click', () => {
      void saveSchedulesToServer();
    });
  }

  function serializeState() {
    return {
      schedules: state.schedules.map((s) => ({
        id: s.id,
        name: s.name,
        form: cloneWeekForm(s.form),
        bacnetPoints: cloneBacnetPoints(s.bacnetPoints),
      })),
      activeScheduleId: state.activeScheduleId,
      holidays: state.holidays.map((h) => ({
        id: h.id,
        date: h.date,
        unoccupied: Boolean(h.unoccupied),
      })),
    };
  }

  function applyPayload(data) {
    if (!data || !Array.isArray(data.schedules) || data.schedules.length === 0) return;
    state.schedules = data.schedules.map((s) => ({
      id: s.id,
      name: s.name,
      form: mergeWeekForm(s.form),
      bacnetPoints: Array.isArray(s.bacnetPoints)
        ? cloneBacnetPoints(s.bacnetPoints)
        : cloneBacnetPoints(INITIAL_BACNET_POINTS),
    }));
    if (
      data.activeScheduleId &&
      state.schedules.some((x) => x.id === data.activeScheduleId)
    ) {
      state.activeScheduleId = data.activeScheduleId;
    }
    state.holidays = Array.isArray(data.holidays)
      ? data.holidays.map((h) => ({
          id: h.id,
          date: h.date,
          unoccupied: Boolean(h.unoccupied),
        }))
      : [];
    state.holidayMultiSelected = new Set();
    state.holidayRangeFrom = null;
    state.holidayRangeTo = null;
  }

  async function saveSchedulesToServer() {
    const st = mountRoot?.querySelector('#schedule-save-status');
    if (st) st.textContent = 'Saving…';
    try {
      const r = await fetch('/api/schedules', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify(serializeState()),
      });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) {
        if (st) st.textContent = data.error || `Save failed (${r.status})`;
        return;
      }
      if (data.diyError) {
        if (st) st.textContent = `Saved; BACnet: ${data.diyError}`;
      } else {
        if (st) st.textContent = 'Saved and pushed to diy-bacnet-server';
      }
    } catch (e) {
      if (st) st.textContent = 'Save failed (network)';
    }
  }

  function connectScheduleWebSocket() {
    try {
      const proto = location.protocol === 'https:' ? 'wss' : 'ws';
      const sock = new WebSocket(`${proto}//${location.host}/ws`);
      sock.addEventListener('message', (ev) => {
        try {
          const msg = JSON.parse(ev.data);
          if (msg.type === 'schedule_updated' && msg.payload) {
            applyPayload(msg.payload);
            syncAll();
            const st = mountRoot?.querySelector('#schedule-save-status');
            if (st) {
              st.textContent = msg.diyError
                ? `Remote update (BACnet: ${msg.diyError})`
                : 'Remote schedule update';
            }
          }
        } catch {
          /* ignore non-JSON */
        }
      });
    } catch {
      /* WebSocket not available */
    }
  }

  function buildScheduleGridElement() {
    const grid = document.createElement('div');
    grid.className = 'schedule-grid';
    grid.style.height = `${GRID_ROWS * HOUR_ROW_PX}px`;
    grid.setAttribute('role', 'img');
    grid.id = 'schedule-grid';

    const corner = document.createElement('div');
    corner.style.gridRow = '1';
    corner.style.gridColumn = '1';
    grid.appendChild(corner);

    for (const day of DAYS) {
      const h = document.createElement('div');
      h.className = 'day-header';
      h.textContent = day.slice(0, 3);
      grid.appendChild(h);
    }

    for (let hr = 0; hr < 24; hr++) {
      const tl = document.createElement('div');
      tl.className = 'time-label';
      tl.textContent = `${String(hr).padStart(2, '0')}:00`;
      grid.appendChild(tl);
      for (let c = 0; c < 7; c++) {
        const cell = document.createElement('div');
        grid.appendChild(cell);
      }
    }

    const layer = document.createElement('div');
    layer.className = 'event-blocks-layer';
    grid.appendChild(layer);

    return grid;
  }

  function onProfileSelectChange() {
    if (!elProfileSelect) return;
    state.activeScheduleId = elProfileSelect.value;
    syncAll();
  }

  function onAddProfile() {
    const nameInput = mountRoot?.querySelector('#new-profile-name');
    const name =
      (nameInput && nameInput.value.trim()) ||
      `Profile ${state.schedules.length + 1}`;
    const active = getActiveProfile();
    const sid = uuid();
    state.schedules.push({
      id: sid,
      name,
      form: cloneWeekForm(active.form),
      bacnetPoints: cloneBacnetPoints(active.bacnetPoints),
    });
    state.activeScheduleId = sid;
    if (nameInput) nameInput.value = '';
    syncAll();
  }

  function onDeleteProfile() {
    if (state.schedules.length <= 1) return;
    const filtered = state.schedules.filter(
      (s) => s.id !== state.activeScheduleId
    );
    state.schedules = filtered;
    state.activeScheduleId = filtered[0].id;
    syncAll();
  }

  function onOperatingChange(ev) {
    const t = ev.target;
    if (!(t instanceof HTMLElement)) return;
    const day = t.dataset.day;
    if (!day) return;
    const profile = getActiveProfile();
    const row = profile.form[day];
    if (t.classList.contains('op-no-schedule') && t instanceof HTMLInputElement) {
      row.noSchedule = t.checked;
    } else if (t.classList.contains('op-start') && t instanceof HTMLInputElement) {
      row.start = t.value;
    } else if (t.classList.contains('op-end') && t instanceof HTMLInputElement) {
      row.end = t.value;
    }
    syncOperatingRowVisual(day);
    syncEventBlocks();
  }

  function syncOperatingRowVisual(day) {
    const profile = getActiveProfile();
    const rowEl = mountRoot?.querySelector(`#operating-table .form-row[data-day="${day}"]`);
    if (!rowEl) return;
    const ns = profile.form[day].noSchedule;
    rowEl.classList.toggle('form-row-muted', ns);
    const start = rowEl.querySelector('.op-start');
    const end = rowEl.querySelector('.op-end');
    if (start instanceof HTMLInputElement) start.disabled = ns;
    if (end instanceof HTMLInputElement) end.disabled = ns;
  }

  function syncHolidayModeButtons() {
    elBtnModeMulti?.classList.toggle(
      'active',
      state.holidayPickerMode === 'multiple'
    );
    elBtnModeRange?.classList.toggle(
      'active',
      state.holidayPickerMode === 'range'
    );
  }

  function setHolidayMode(mode) {
    state.holidayPickerMode = mode;
    state.holidayMultiSelected = new Set();
    state.holidayRangeFrom = null;
    state.holidayRangeTo = null;
    syncHolidayModeButtons();
    renderHolidayPicker();
    syncHolidayAddButton();
  }

  function onHolidayDayClick(iso) {
    if (state.holidayPickerMode === 'multiple') {
      if (state.holidayMultiSelected.has(iso)) {
        state.holidayMultiSelected.delete(iso);
      } else {
        state.holidayMultiSelected.add(iso);
      }
    } else {
      if (!state.holidayRangeFrom) {
        state.holidayRangeFrom = iso;
        state.holidayRangeTo = null;
      } else if (!state.holidayRangeTo) {
        state.holidayRangeTo = iso;
      } else {
        state.holidayRangeFrom = iso;
        state.holidayRangeTo = null;
      }
    }
    renderHolidayPicker();
    syncHolidayAddButton();
  }

  function onHolidayAddClick() {
    if (state.holidayPickerMode === 'multiple') {
      const isoList = [...state.holidayMultiSelected];
      if (!isoList.length) return;
      state.holidays = mergeNewHolidayDates(state.holidays, isoList);
      state.holidayMultiSelected = new Set();
    } else {
      if (!state.holidayRangeFrom) return;
      const a = state.holidayRangeFrom;
      const b = state.holidayRangeTo ?? a;
      const days = eachDayIsoBetween(a, b);
      state.holidays = mergeNewHolidayDates(state.holidays, days);
      state.holidayRangeFrom = null;
      state.holidayRangeTo = null;
    }
    renderHolidayPicker();
    syncHolidayList();
    syncHolidayAddButton();
  }

  function onHolidayListChange(ev) {
    const t = ev.target;
    if (!(t instanceof HTMLInputElement) || t.type !== 'checkbox') return;
    const id = t.dataset.holidayId;
    if (!id) return;
    const h = state.holidays.find((x) => x.id === id);
    if (h) h.unoccupied = t.checked;
  }

  function onHolidayListClick(ev) {
    const btn = ev.target && ev.target.closest && ev.target.closest('[data-action="holiday-delete"]');
    if (!(btn instanceof HTMLElement)) return;
    const id = btn.dataset.holidayId;
    if (!id) return;
    state.holidays = state.holidays.filter((h) => h.id !== id);
    syncHolidayList();
    renderHolidayPicker();
  }

  function syncHolidayAddButton() {
    if (!elBtnHolidayAdd || !elHolidayRangeHint) return;
    const multi = state.holidayPickerMode === 'multiple';
    const rangePartial = Boolean(
      state.holidayRangeFrom && !state.holidayRangeTo
    );
    const rangeReady = Boolean(state.holidayRangeFrom && state.holidayRangeTo);

    if (multi) {
      elBtnHolidayAdd.disabled = state.holidayMultiSelected.size === 0;
      elBtnHolidayAdd.textContent = 'Add selected dates as holidays';
      elBtnHolidayAdd.title = '';
      elHolidayRangeHint.hidden = true;
    } else {
      elBtnHolidayAdd.disabled = !state.holidayRangeFrom;
      elBtnHolidayAdd.textContent = rangePartial
        ? 'Add this day (pick end for a range)'
        : rangeReady
          ? 'Add range as holidays'
          : 'Select start date on the calendar';
      elBtnHolidayAdd.title = rangePartial
        ? 'Pick the end day to complete the range (or add a single day)'
        : '';
      elHolidayRangeHint.hidden = !rangePartial;
      if (rangePartial) {
        elHolidayRangeHint.textContent =
          'Second click sets the end of the range. Or use the button above to add just the first day.';
      }
    }
  }

  function renderHolidayPicker() {
    if (!elHolidayPickerHost) return;

    const y = state.holidayViewYear;
    const m0 = state.holidayViewMonth0;
    const first = new Date(y, m0, 1);
    const monthLabel = first.toLocaleDateString(undefined, {
      month: 'long',
      year: 'numeric',
    });

    const startWeekday = first.getDay();

    const already = holidayDateSet();
    const rangeMid = new Set();
    if (
      state.holidayPickerMode === 'range' &&
      state.holidayRangeFrom &&
      state.holidayRangeTo
    ) {
      const between = eachDayIsoBetween(
        state.holidayRangeFrom,
        state.holidayRangeTo
      );
      for (const iso of between) {
        if (iso !== state.holidayRangeFrom && iso !== state.holidayRangeTo) {
          rangeMid.add(iso);
        }
      }
    }

    const cells = [];
    const totalCells = 42;
    let dayCounter = 1 - startWeekday;
    for (let i = 0; i < totalCells; i++) {
      const cellDate = new Date(y, m0, dayCounter);
      const iso = formatISO(cellDate);
      const inThisMonth = cellDate.getMonth() === m0;

      const classes = ['van-cal-day'];
      if (!inThisMonth) classes.push('outside');

      if (already.has(iso)) classes.push('already-holiday');

      if (state.holidayPickerMode === 'multiple') {
        if (state.holidayMultiSelected.has(iso)) classes.push('picker-selected');
      } else {
        if (state.holidayRangeFrom === iso) classes.push('range-from');
        if (state.holidayRangeTo === iso) classes.push('range-to');
        if (rangeMid.has(iso)) classes.push('range-between');
      }

      const label = String(cellDate.getDate());
      cells.push(
        `<button type="button" class="${classes.join(' ')}" data-action="holiday-day" data-iso="${iso}" aria-pressed="${state.holidayPickerMode === 'multiple' ? state.holidayMultiSelected.has(iso) : state.holidayRangeFrom === iso || state.holidayRangeTo === iso || rangeMid.has(iso)}">${label}</button>`
      );
      dayCounter++;
    }

    elHolidayPickerHost.innerHTML = `
      <div class="van-cal" role="application" aria-label="Holiday date picker">
        <div class="van-cal-nav">
          <button type="button" class="van-cal-nav-btn" data-action="holiday-nav" data-dir="-1" aria-label="Previous month">‹</button>
          <span class="van-cal-month">${monthLabel}</span>
          <button type="button" class="van-cal-nav-btn" data-action="holiday-nav" data-dir="1" aria-label="Next month">›</button>
        </div>
        <div class="van-cal-weekdays" aria-hidden="true">
          ${['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa']
            .map((w) => `<span>${w}</span>`)
            .join('')}
        </div>
        <div class="van-cal-days">
          ${cells.join('')}
        </div>
      </div>
    `;

    elHolidayPickerHost.querySelectorAll('[data-action="holiday-day"]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const iso = btn.getAttribute('data-iso');
        if (iso) onHolidayDayClick(iso);
      });
    });

    elHolidayPickerHost.querySelectorAll('[data-action="holiday-nav"]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const dir = Number(btn.getAttribute('data-dir') || '0');
        let m = state.holidayViewMonth0 + dir;
        let yy = state.holidayViewYear;
        if (m < 0) {
          m = 11;
          yy--;
        } else if (m > 11) {
          m = 0;
          yy++;
        }
        state.holidayViewMonth0 = m;
        state.holidayViewYear = yy;
        renderHolidayPicker();
      });
    });
  }

  function syncHolidayList() {
    if (!elHolidayListHost) return;
    if (state.holidays.length === 0) {
      elHolidayListHost.innerHTML =
        '<p class="holiday-empty">No holidays configured.</p>';
      return;
    }
    elHolidayListHost.innerHTML = `<ul class="holiday-list">${state.holidays
      .map(
        (h) => `
      <li class="holiday-list-item">
        <span class="holiday-date">
          ${formatPrettyLong(h.date)}
          <span class="holiday-iso">(${h.date})</span>
        </span>
        <label class="holiday-occ">
          <input type="checkbox" data-holiday-id="${h.id}" ${h.unoccupied ? 'checked' : ''} />
          Unoccupied
        </label>
        <button type="button" class="btn danger btn-sm" data-action="holiday-delete" data-holiday-id="${h.id}">Delete</button>
      </li>`
      )
      .join('')}</ul>`;
  }

  function onBacnetAdd() {
    const n = mountRoot?.querySelector('#bacnet-new-name');
    const o = mountRoot?.querySelector('#bacnet-new-oid');
    const name = n && 'value' in n ? String(n.value).trim() : '';
    if (!name) return;
    const oidRaw = o && 'value' in o ? String(o.value).trim() : '';
    const profile = getActiveProfile();
    profile.bacnetPoints.push({
      id: uuid(),
      name,
      objectId: oidRaw || undefined,
    });
    if (n && 'value' in n) n.value = '';
    if (o && 'value' in o) o.value = '';
    syncBacnetRows();
  }

  function onBacnetInput(ev) {
    const t = ev.target;
    if (!(t instanceof HTMLInputElement)) return;
    const id = t.dataset.pointId;
    if (!id) return;
    const profile = getActiveProfile();
    const p = profile.bacnetPoints.find((x) => x.id === id);
    if (!p) return;
    if (t.classList.contains('bac-name')) {
      p.name = t.value;
    } else if (t.classList.contains('bac-oid')) {
      const v = t.value.trim();
      p.objectId = v || undefined;
    }
  }

  function onBacnetClick(ev) {
    const btn = ev.target && ev.target.closest && ev.target.closest('[data-action="bacnet-remove"]');
    if (!(btn instanceof HTMLElement)) return;
    const id = btn.dataset.pointId;
    if (!id) return;
    const profile = getActiveProfile();
    profile.bacnetPoints = profile.bacnetPoints.filter((p) => p.id !== id);
    syncBacnetRows();
  }

  function syncBacnetRows() {
    if (!elBacnetTbody) return;
    const profile = getActiveProfile();
    elBacnetTbody.innerHTML = profile.bacnetPoints
      .map(
        (p) => `
      <div class="bacnet-row" data-point-row="${p.id}">
        <input class="control bac-name" data-point-id="${p.id}" value="${escapeAttr(p.name)}" aria-label="Name for point ${p.id}" />
        <input class="control bac-oid" data-point-id="${p.id}" placeholder="e.g. AV:1" value="${escapeAttr(p.objectId ?? '')}" aria-label="Object ID for ${escapeAttr(p.name)}" />
        <div class="bacnet-actions">
          <button type="button" class="btn danger" data-action="bacnet-remove" data-point-id="${p.id}">Remove</button>
        </div>
      </div>`
      )
      .join('');
  }

  function escapeAttr(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/</g, '&lt;');
  }

  function syncProfileSelect() {
    if (!elProfileSelect) return;
    const cur = state.activeScheduleId;
    elProfileSelect.innerHTML = state.schedules
      .map(
        (s) =>
          `<option value="${s.id}">${escapeAttr(s.name)}</option>`
      )
      .join('');
    elProfileSelect.value = state.schedules.some((s) => s.id === cur)
      ? cur
      : state.schedules[0].id;
    state.activeScheduleId = elProfileSelect.value;
    if (elDeleteProfile) {
      elDeleteProfile.disabled = state.schedules.length <= 1;
      elDeleteProfile.title =
        state.schedules.length <= 1
          ? 'Keep at least one schedule'
          : 'Delete the active schedule';
    }
  }

  function syncCalendarHint() {
    const p = getActiveProfile();
    if (elCalendarHint) {
      elCalendarHint.innerHTML = `Schedule: <strong>${escapeHtml(p.name)}</strong> — days with <strong>No schedule</strong> unchecked show their start–stop window below.`;
    }
    if (elScheduleGrid) {
      elScheduleGrid.setAttribute(
        'aria-label',
        `Weekly operating hours for ${p.name}`
      );
    }
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function syncOperatingHint() {
    const el = mountRoot?.querySelector('#operating-hint');
    const p = getActiveProfile();
    if (el) {
      el.innerHTML = `For <strong>${escapeHtml(p.name)}</strong>: check <strong>No schedule</strong> on a day to treat it as off / unoccupied (it will not appear on the calendar). Uncheck to set start and stop for that day.`;
    }
  }

  function syncBacnetHint() {
    const el = mountRoot?.querySelector('#bacnet-hint');
    const p = getActiveProfile();
    if (el) {
      el.innerHTML = `Points assigned to the <strong>${escapeHtml(p.name)}</strong> schedule only (switch schedule above to edit another profile's list). Object ID is optional metadata for integration (e.g. AV:1).`;
    }
  }

  function syncOperatingValues() {
    const profile = getActiveProfile();
    for (const day of DAYS) {
      const row = mountRoot?.querySelector(`#operating-table .form-row[data-day="${day}"]`);
      if (!row) continue;
      const f = profile.form[day];
      const cb = row.querySelector('.op-no-schedule');
      const st = row.querySelector('.op-start');
      const en = row.querySelector('.op-end');
      if (cb instanceof HTMLInputElement) cb.checked = f.noSchedule;
      if (st instanceof HTMLInputElement) {
        st.value = f.start;
        st.disabled = f.noSchedule;
      }
      if (en instanceof HTMLInputElement) {
        en.value = f.end;
        en.disabled = f.noSchedule;
      }
      row.classList.toggle('form-row-muted', f.noSchedule);
    }
  }

  function syncEventBlocks() {
    if (!elEventLayer) return;
    const p = getActiveProfile();
    const blocks = blocksFromOperatingWeek(p.form, p.name);
    elEventLayer.innerHTML = '';
    for (const block of blocks) {
      const st = getBlockStyle(block);
      const div = document.createElement('div');
      div.className = 'event-block';
      div.style.left = st.left;
      div.style.width = st.width;
      div.style.top = st.top;
      div.style.height = st.height;
      div.title = `${p.name} · ${block.day} ${block.start}–${block.end}`;
      div.innerHTML = `<span class="event-label">${escapeHtml(block.label)}</span>`;
      elEventLayer.appendChild(div);
    }
  }

  function syncAll() {
    syncProfileSelect();
    syncCalendarHint();
    syncOperatingHint();
    syncBacnetHint();
    syncOperatingValues();
    syncEventBlocks();
    syncBacnetRows();
    syncHolidayList();
    renderHolidayPicker();
    syncHolidayAddButton();
    syncHolidayModeButtons();
  }

  function boot() {
    if (!mountRoot) return;
    buildLayout();
    syncAll();
  }

  /**
   * Mount the weekly schedule + holiday + BACnet UI into `el` (e.g. #bas-panel-schedule).
   * @param {HTMLElement} el
   */
  function init(el) {
    if (!(el instanceof HTMLElement)) return;
    mountRoot = el;
    void (async () => {
      let loaded = false;
      try {
        const r = await fetch('/api/schedules', { headers: { Accept: 'application/json' } });
        if (r.ok) {
          const data = await r.json();
          if (data && Array.isArray(data.schedules) && data.schedules.length) {
            applyPayload(data);
            loaded = true;
          }
        }
      } catch {
        /* static hosting or backend down */
      }
      boot();
      const st = mountRoot?.querySelector('#schedule-save-status');
      if (st) st.textContent = loaded ? 'Loaded from diy-bas backend' : '';
      connectScheduleWebSocket();
    })();
  }

  window.DiyBasSchedule = { init };
})();
