from __future__ import annotations

import sqlite3
import threading
import time
from pathlib import Path
from typing import Any

from .config import settings

DB_PATH = settings.data_dir / 'trends.sqlite3'
_LOCK = threading.Lock()


def _connect() -> sqlite3.Connection:
    settings.data_dir.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=30, isolation_level=None, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA synchronous=NORMAL')
    conn.execute('PRAGMA temp_store=MEMORY')
    return conn


def initialize() -> None:
    with _LOCK:
        conn = _connect()
        try:
            conn.execute(
                '''
                CREATE TABLE IF NOT EXISTS trend_samples (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    point_id TEXT NOT NULL,
                    ts INTEGER NOT NULL,
                    value_real REAL,
                    value_text TEXT
                )
                '''
            )
            conn.execute('CREATE INDEX IF NOT EXISTS idx_trend_point_ts ON trend_samples(point_id, ts)')
            conn.execute('CREATE INDEX IF NOT EXISTS idx_trend_ts ON trend_samples(ts)')
        finally:
            conn.close()


def _normalize_value(value: Any) -> tuple[float | None, str | None]:
    if value is None:
        return None, None
    if isinstance(value, bool):
        return (1.0 if value else 0.0), 'true' if value else 'false'
    if isinstance(value, (int, float)):
        return float(value), str(value)
    return None, str(value)


def insert_samples(samples: list[dict[str, Any]]) -> int:
    if not samples:
        return 0
    rows: list[tuple[str, int, float | None, str | None]] = []
    for sample in samples:
        point_id = str(sample.get('pointId', '')).strip()
        if not point_id:
            continue
        ts = int(sample.get('ts') or time.time())
        real, text = _normalize_value(sample.get('value'))
        rows.append((point_id, ts, real, text))
    if not rows:
        return 0
    with _LOCK:
        conn = _connect()
        try:
            conn.execute('BEGIN')
            conn.executemany(
                'INSERT INTO trend_samples (point_id, ts, value_real, value_text) VALUES (?, ?, ?, ?)',
                rows,
            )
            conn.execute('COMMIT')
            return len(rows)
        except Exception:
            conn.execute('ROLLBACK')
            raise
        finally:
            conn.close()


def purge_old(retention_days: int | None = None) -> int:
    days = max(1, int(retention_days or settings.trend_retention_days))
    cutoff = int(time.time()) - (days * 86400)
    with _LOCK:
        conn = _connect()
        try:
            cur = conn.execute('DELETE FROM trend_samples WHERE ts < ?', (cutoff,))
            return int(cur.rowcount or 0)
        finally:
            conn.close()


def query_samples(point_id: str, start_ts: int, end_ts: int, limit: int = 2000) -> list[dict[str, Any]]:
    limit = max(1, min(int(limit), 10000))
    with _LOCK:
        conn = _connect()
        try:
            cur = conn.execute(
                '''
                SELECT point_id, ts, value_real, value_text
                FROM trend_samples
                WHERE point_id = ? AND ts >= ? AND ts <= ?
                ORDER BY ts ASC
                LIMIT ?
                ''',
                (point_id, int(start_ts), int(end_ts), limit),
            )
            rows = cur.fetchall()
        finally:
            conn.close()
    out: list[dict[str, Any]] = []
    for row in rows:
        val: Any = row['value_real'] if row['value_real'] is not None else row['value_text']
        out.append({'pointId': row['point_id'], 'ts': int(row['ts']), 'value': val})
    return out


def db_path() -> Path:
    return Path(DB_PATH)
